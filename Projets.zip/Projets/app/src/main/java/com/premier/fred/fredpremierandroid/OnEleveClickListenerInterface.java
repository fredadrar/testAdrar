package com.premier.fred.fredpremierandroid;

public interface OnEleveClickListenerInterface {

    void onEleveClick(EleveBean eleve);

    void onEleveLongClick(EleveBean eleve);
}
